package feedback.entities;

public class User {
	private int id;
	private String name, emailaddress
	,phonenumber
	, password,role;
	public User( String name, String emailaddress, String phonenumber, String password, String role) {
		
		
		this.name = name;
		this.emailaddress = emailaddress;
		this.phonenumber = phonenumber;
		this.password = password;
		this.role = role;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailaddress() {
		return emailaddress;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	
	public String getPassword() {
		return password;
	}
	public String getRole() {
		return role;
	}
	

}
