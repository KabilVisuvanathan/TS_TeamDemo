const BASE_URL = "http://localhost:8080/FeedbackSystem/";


const registerForm = document.getElementById("register-from");

const nameEl = document.getElementById("name");
const phoneEl = document.getElementById("phone");
const emailEl = document.getElementById("email");
const passwordEl = document.getElementById("password");
const confirmPasswordEl = document.getElementById("confirm-password");


let globalErrorTracker = {};

registerForm.addEventListener("submit",(event)=>{
	event.preventDefault();
	let res =validateFormData();
	if(res){
		async function addUser(){

			try{
				
				let payload = {
					user:res
				}
				
				let response = await fetch(BASE_URL+"/Registration",{
					method:"POST",
					headers:{"Content-type":"application/json"},
					body:JSON.stringify(payload)
				});
				
				
				let data = await response.json();
				console.log(data);
				return data.exists;

			
				
			}catch(err){
				console.log(err);
				return false;
			}	
		}
		addUser();
	}else{
		alert(JSON.stringify(globalErrorTracker));
	}
	
});



//async function register(){
	
//}


function validateFormData(){
	let username = nameEl.value;
	let email  =emailEl.value;
	let phonenumber = phoneEl.value;
	let password = passwordEl.value;
	let confirm_password = confirmPasswordEl.value;
	
	let errors = {};

	
	if(username.trim()===""){
		errors["username"] = "Username can't be empty";
	}
	if(phonenumber.trim().length<10){
		errors["phonenumber"] = "Invalid phonenumber.";
	}
	
	if(password.length<6){
		errors["password"] = "Minimum Password letters should be 6";
	}
	
	if(password.trim()!==confirm_password.trim()){
		errors["password"] = "Password does not match";
	}
	globalErrorTracker=errors;
	return Object.keys(errors).length===0?{username,email,phonenumber,password}:false;
	
}



