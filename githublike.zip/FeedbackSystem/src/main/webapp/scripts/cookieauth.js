function setCookie(emailaddress,phonenumber,role) {
    document.cookie = `emailaddress=${emailaddress};phonenumber=${phonenumber};role=${role}; path=/; expires=${new Date(Date.now() + 86400000*10).toUTCString()}`;
}

