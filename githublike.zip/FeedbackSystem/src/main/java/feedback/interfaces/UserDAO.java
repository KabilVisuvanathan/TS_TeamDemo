package feedback.interfaces;

import java.sql.SQLException;
import java.util.ArrayList;

import feedback.entities.User;


public interface UserDAO {
	
	public User getUserByEmailaddress(String emailaddress) throws SQLException;
	public ArrayList<User> getAllUsers()  throws SQLException;
	public void updateUser(User user) throws SQLException;
	public void addUser(User user) throws SQLException;
	public void deleteUser(int id) throws SQLException;
}
