package feedback.dataaccessobjects;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import feedback.entities.CallHistory;
import feedback.entities.Employee;
import feedback.entities.Feedback;
import feedback.entities.PhoneNumber;
import feedback.entities.User;
import feedback.services.DBconnection;

public class CallHistoryDAO {
		
	public ArrayList<CallHistory> getAllCallHistory() throws SQLException{
		

		Connection con =DBconnection.getConnection();
			
			String historyQuery = "select * from call_history";
			
			PreparedStatement stmt = con.prepareStatement(historyQuery);
			
			
			ResultSet rs = stmt.executeQuery();
			
			ArrayList<CallHistory> calls = new ArrayList<CallHistory>();
			EmployeeDAO empdao = new EmployeeDAO();
			
			UserDAOImplementation userdao = new UserDAOImplementation();
			PhoneNumberDAO phdao = new PhoneNumberDAO();
			
			FeedbackDAO feedbackdao = new FeedbackDAO();
			while(rs.next()) {
				int historyid = rs.getInt(1);
				int empid= rs.getInt(2);
				int userid= rs.getInt(3);
				int phonenumberid= rs.getInt(4);
				int feedbackid= rs.getInt(5);
				double duration  = rs.getInt(6);
				LocalDateTime createdAt = rs.getTimestamp(7).toLocalDateTime();
				Employee employee=empdao.getEmployeeById(empid);
				User user = userdao.getUserByid(userid);
				Feedback fb = feedbackdao.getFeedBack(feedbackid);
				PhoneNumber pn =phdao.getPhonenumberById(phonenumberid);
				CallHistory ch =new  CallHistory(employee, user, pn, fb, duration, createdAt);
				
				calls.add(ch);
			}
			
			return calls;
	}
}
