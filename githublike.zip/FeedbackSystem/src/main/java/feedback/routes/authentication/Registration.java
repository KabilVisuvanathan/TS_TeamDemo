package feedback.routes.authentication;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import feedback.util.JSONHandler;
import feedback.dataaccessobjects.UserDAOImplementation;
import feedback.entities.User;

public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		JSONObject responseObject =  JSONHandler.parse(request.getReader());
		JSONObject userobj = new JSONObject(responseObject.get("user").toString() );
		
		UserDAOImplementation dao =  new UserDAOImplementation();
		String emailaddress = userobj.get("email").toString();
		String phonenumber = userobj.get("phonenumber").toString();
		User user=null;
		try {
			 user =dao.getUserByEmailaddress(emailaddress);
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}

		if(user!=null) {
			
			response.setStatus(204);
			response.setContentType("application/json");
			String out = "{'exists':true,'message':'Emailaddress already exists.'}";
			response.getWriter().write(new JSONObject(out).toString());
			return;
		}else {

			 user= null;
			try {
				user =dao.getUserByPhonenumber(phonenumber);
			} catch (JSONException | SQLException e) {
				
				System.out.println(e.getMessage());
			}
			
			if(user!=null) {
				response.setStatus(204);
				response.setContentType("application/json");
				String out = "{'exists':true,'message':'Phonenumber already exists.'}";
				response.getWriter().write(new JSONObject(out).toString());
				return;
			}else {
				//Now the user can be stored in db
				String name = userobj.getString("username");
				String password = userobj.getString("password");
//				request.//Getting url to decide the role
//				new User();
			}
		}

	System.out.println(userobj);
		

		response.getWriter().write(responseObject.toString());
	}

}
