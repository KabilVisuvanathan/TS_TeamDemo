package feedback.dataaccessobjects;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

import feedback.entities.Feedback;
import feedback.services.DBconnection;

public class FeedbackDAO {
	
	
	
	public Feedback getFeedBack(int id) throws SQLException {
		
	Connection con =DBconnection.getConnection();
		
		String feedbackRetriveQuery = "select * from feedbacks where id = ?";
		PreparedStatement stmt = con.prepareStatement(feedbackRetriveQuery);
		stmt.setInt(1, id);
		
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			int feedbackid = rs.getInt(1);
			String content = rs.getString(2);
			double ratings = rs.getDouble(3);
			int tagid = rs.getInt(4);
			boolean flaged = rs.getBoolean(5);
			LocalDateTime createdAt =rs.getTimestamp(6).toLocalDateTime();
			LocalDateTime updatedAt =rs.getTimestamp(7).toLocalDateTime();
			
			
			Feedback fb = new Feedback(content, ratings, tagid);
			fb.setId(feedbackid);
			fb.setTagid(tagid);
			fb.setFlagged(flaged);
			fb.setCreatedAt(createdAt);
			fb.setUpdatedAt(updatedAt);
			
			return fb;
			
			}
		
		return null;
	}
	
	
	
	public void addFeedback(Feedback fb) throws SQLException {
		Connection con = DBconnection.getConnection();
		String addFeedbackQuery = "insert into feedbacks(content,ratings,tagid) values(?,?,?)";
		PreparedStatement stmt = con.prepareStatement(addFeedbackQuery);	
		stmt.setString(1, fb.getContent());
		stmt.setDouble(2, fb.getRatings());
		stmt.setInt(3, fb.getTagid());
		
		int status = stmt.executeUpdate();
		
		if(status>0) {
			System.out.println("Feedback added");
		}
		else {
			System.out.println("Failded to add Feedback");
		}
		
	}
	public void updateFeedback(Feedback fb) throws SQLException {
		Connection con = DBconnection.getConnection();
		String feedbackUpdateQuery = "update feedbacks set content=?,ratings=?,tagid=?,flaged? where id=?";
		PreparedStatement stmt = con.prepareStatement(feedbackUpdateQuery);	
		stmt.setString(1, fb.getContent());
		stmt.setDouble(2, fb.getRatings());
		stmt.setInt(3, fb.getTagid());
		stmt.setBoolean(4, fb.getFlagged());
		stmt.setInt(5, fb.getId());
		
		stmt.executeUpdate();
	}
	
	public void deleteFeedback(int id) throws SQLException {
		Connection con = DBconnection.getConnection();
		String feedbackUpdateQuery = "delete from feedbacks where id=?";
		PreparedStatement stmt = con.prepareStatement(feedbackUpdateQuery);	
		stmt.setInt(1, id);
		stmt.executeUpdate();
	}
}
