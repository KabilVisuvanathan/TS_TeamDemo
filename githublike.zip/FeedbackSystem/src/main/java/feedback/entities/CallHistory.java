package feedback.entities;

import java.time.LocalDateTime;

public class CallHistory {
	private int id;
	private Employee employee;
	private User user;
	private PhoneNumber phonenumber;
	private Feedback feedback;
	private double duration;
	private LocalDateTime createdAt;
	public CallHistory(Employee employee, User user, PhoneNumber phonenumber, Feedback feedback, double duration,
			LocalDateTime createdAt) {
		super();
		this.employee = employee;
		this.user = user;
		this.phonenumber = phonenumber;
		this.feedback = feedback;
		this.duration = duration;
		this.createdAt = createdAt;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public PhoneNumber getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(PhoneNumber phonenumber) {
		this.phonenumber = phonenumber;
	}
	public Feedback getFeedback() {
		return feedback;
	}
	public void setFeedback(Feedback feedback) {
		this.feedback = feedback;
	}
	public double getDuration() {
		return duration;
	}
	public void setDuration(double duration) {
		this.duration = duration;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	
	
}
