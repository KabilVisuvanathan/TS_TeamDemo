const BASE_URL = "http://localhost:8080/FeedbackSystem/";


async function isEmailExists(emailaddress){

	try{
		
		let payload = {
			email:emailaddress
		}
		
		let response = await fetch(BASE_URL+"/Registration",{
			method:"POST",
			headers:{"Content-type":"application/json"},
			body:JSON.stringify(payload)
		});
		let data = await response.json();
		console.log(data);
		return data.exists;
		
	}catch(err){
		console.log(err);
	return false;
		}	
}

async function isPhonenumberExists(phonenumber){

	try{
		
		let payload = {
			phonenumber:phonenumber
		}
		
		let response = await fetch(BASE_URL+"/Registration",{
			method:"POST",
			headers:{"Content-type":"application/json"},
			body:JSON.stringify(payload)
		});
		let data = await response.json();
		console.log(data);
		return data.exists;

	
		
	}catch(err){
		console.log(err);
		return false;
	}	
}