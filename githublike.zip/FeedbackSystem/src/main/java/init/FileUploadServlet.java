package init;

import java.io.*;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;


//@WebServlet("/FileUploadServlet")
//@MultipartConfig(
//    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
//    maxFileSize = 1024 * 1024 * 10, // 10MB
//    maxRequestSize = 1024 * 1024 * 50 // 50MB
//)
public class FileUploadServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String REPO_BASE_PATH = "/opt/all-repos/";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Request received...");

        String repoName = request.getParameter("repo");
        Part filePart = request.getPart("file"); // ✅ Corrected key name

        if (repoName == null || filePart == null) {
        	System.out.println(repoName+" s "+filePart);
            response.getWriter().write("Missing repository name or file.");
            return;
        }

        // Locate the Git repository
        File repoDir = new File(REPO_BASE_PATH + repoName + ".git");
        if (!repoDir.exists()) {
            response.getWriter().write("Repository does not exist.");
            return;
        }

        // Save the uploaded file
        File file = new File(repoDir.getParent(), filePart.getSubmittedFileName());
        try (InputStream fileContent = filePart.getInputStream();
             FileOutputStream fos = new FileOutputStream(file)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fileContent.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
        }

        // Commit and push using JGit
        try (Repository repository = new FileRepositoryBuilder().setGitDir(repoDir).build();
             Git git = new Git(repository)) {
            
            git.add().addFilepattern(file.getName()).call();
            git.commit().setMessage("Added " + file.getName()).call();
            git.push().call();
            
            response.getWriter().write("File uploaded and pushed successfully.");
        } catch (GitAPIException e) {
            response.getWriter().write("Git operation failed: " + e.getMessage());
        }
    }
}

