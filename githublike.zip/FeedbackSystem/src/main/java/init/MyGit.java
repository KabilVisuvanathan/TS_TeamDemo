package init;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.lib.Ref;  // Add this import
import org.eclipse.jgit.lib.RefDatabase;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.transport.ReceivePack;
import org.eclipse.jgit.transport.RefSpec;
import org.eclipse.jgit.transport.UploadPack;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class MyGit extends HttpServlet {

    private static final long serialVersionUID = 1L;
	private static final String REPO_PATH = "/opt/git-repos/";
	private static final String TEMP_REPO_PATH = "/tmp/kabil-working/";

	
	   protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        System.out.println("hii");
	        String repoName = request.getPathInfo();
	        if (repoName == null || repoName.equals("/")) {
	            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid repository name");
	            return;
	        }

	        // Remove the leading slash
	        repoName = repoName.substring(1);
	        if (repoName.contains("/")) {
		        repoName = repoName.substring(0, repoName.indexOf("/"));
		    }
		    System.out.println(repoName);
		    System.out.println("Repository name: " + repoName);
	        String sourceRepoPath = REPO_PATH + repoName;
	        
	        File repoDir = new File(sourceRepoPath);
	        if (!repoDir.exists()) {
	            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Source repository not found");
	            return;
	        }

	        // Respond with the necessary Git data
	        response.setStatus(HttpServletResponse.SC_OK);
	        response.setContentType("application/x-git-upload-pack-advertisement");

	
	        response.setHeader("Expires", "Fri, 01 Jan 1980 00:00:00 GMT");
	        response.setHeader("Pragma", "no-cache");
	        response.setHeader("Cache-Control", "no-cache, max-age=0, must-revalidate");

	        Repository repository = Git.open(repoDir).getRepository();

	     // Get all refs (branches, tags, etc.)
	     List<Ref> refs = repository.getRefDatabase().getRefs();

	     try {
	    	    // Prepare the response stream to send data

	    	    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(), StandardCharsets.UTF_8));

	    	    // Service announcement
	    	    String service = "git-upload-pack";
	    	    String serviceLine = "# service=" + service + "\n";  // Space after #
	    	    int serviceLength = serviceLine.length() + 4;
	    	    String servicePacket = String.format("%04x%s", serviceLength, serviceLine);

	    	    // Debugging
	    	    System.out.println("Service Packet: " + servicePacket);

	    	    writer.write(servicePacket);
	    	    writer.write("0000");  // Flush packet after service line

	    	    // Write refs
	    	    for (Ref ref : refs) {
	    	        String refLine = String.format("%s %s\n", ref.getObjectId().getName(), ref.getName());
	    	        int refLength = refLine.length() + 4;
	    	        String refPacket = String.format("%04x%s", refLength, refLine);

	    	        // Debugging
	    	        System.out.println("Ref Packet: " + refPacket);

	    	        writer.write(refPacket);
	    	    }

	    	    // Final flush packet
	    	    writer.write("0000");

	    	    writer.flush();
	    	    writer.close();
	    	} catch (IOException e) {
	    	    if (!response.isCommitted()) {
	    	        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error handling the Git request.");
	    	    }
	    	    e.printStackTrace();
	    	} catch (Exception e) {
	    	    if (!response.isCommitted()) {
	    	        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred.");
	    	    }
	    	    e.printStackTrace();
	    	}
	    }
//	protected void doGet(HttpServletRequest request, HttpServletResponse response)
//	        throws ServletException, IOException {
//
//	    System.out.println("GET request received for Git push");
//
//	    // Extract repository name from URL
//	    String repoName = request.getPathInfo();
//
//	    if (repoName == null || repoName.equals("/")) {
//	        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid repository name");
//	        return;
//	    }
//
//	    repoName = repoName.substring(1);  // Remove leading "/"
//
//	    // If there is an additional path (like /info/refs), trim the repository name
//	    if (repoName.contains("/")) {
//	        repoName = repoName.substring(0, repoName.indexOf("/"));
//	    }
//	    System.out.println(repoName);
//	    System.out.println("Repository name: " + repoName);
//
//	    // Define the repository directory path
//	    File repoDir = new File(REPO_PATH+repoName );
//	    System.out.println(repoDir.exists());
//	    // Check if the repository exists
//	    if (!repoDir.exists() || !repoDir.isDirectory()) {
//	        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Repository not found: " + repoName);
//	        return;
//	    }
//
//	    // Ensure the request is for git-receive-pack (push)
//	    String service = request.getParameter("service");
//	   
//	    System.out.println(service);
//	    if (service == null || !service.equals("git-receive-pack")) {
//	        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid service type");
//	        return;
//	    }
//
//	    try {
//	        // Open the repository
//	        Repository repository = Git.open(repoDir).getRepository();
//	        
//	        Collection<Ref> refs = new Git(repository).branchList().call();
//
//	       
//	        System.out.println(refs.size());
//	        // Prepare response
//	        response.setContentType("application/x-git-receive-pack-advertisement");
//	        response.setStatus(HttpServletResponse.SC_OK);
//
//	        OutputStream out = response.getOutputStream();
//	        Writer writer = new OutputStreamWriter(out, StandardCharsets.UTF_8);
//
//	        // The service Git expects (for receiving pushes)
////	        String service = "git-receive-pack";
//
//	        // Construct service declaration
//	        String serviceLine = "# service=" + service + "\n";  // Ensure newline is added
//
//	        // Compute length (4 hex digits + serviceLine length)
//	        int serviceLength = serviceLine.length() + 4;
//
//	        // Format service packet correctly
//	        String servicePacket = String.format("%04x%s", serviceLength, serviceLine);
//
//	        // Debugging: Print service line
//	        System.out.println("Service Packet: " + servicePacket);
//
//	        // Write service declaration
//	        writer.write(servicePacket);
//
//	        // Write a flush packet (0000) to indicate end of service announcement
//	        writer.write("0000");
//
//	        // Now send refs
//	        for (Ref ref : refs) {
//	            String refLine = String.format("%s %s\n", ref.getObjectId().getName(), ref.getName());
//
//	            // Compute length (4 hex digits + refLine length)
//	            int refLength = refLine.length() + 4;
//
//	            // Format ref packet
//	            String refPacket = String.format("%04x%s", refLength, refLine);
//
//	            // Debugging: Print each ref packet
//	            System.out.println("Ref Packet: " + refPacket);
//
//	            writer.write(refPacket);
//	        }
//
//	        // Final flush packet
//	        writer.write("0000");
//
//	        writer.flush();
//	        writer.close();
//
//	        System.out.println("Git push discovery successful for: " + repoName);
//
////	        Git git = new Git(repository);
////	        // Push changes to the remote server (you would need to configure a remote URL)
////	        git.push()
////	           .setRemote("master")
////	           .setRefSpecs(new RefSpec("refs/heads/master"))
////	           .call();
////
////	        System.out.println("Changes pushed to the remote repository.");
////
////	        // Respond with success
////	        response.setStatus(HttpServletResponse.SC_OK);
////	        response.getWriter().write("Changes successfully pushed to the remote");
//	        // Get all refs (branches, tags)
////	        List<Ref> refs = repository.getRefDatabase().getRefs();
////
////	        System.out.println("Serving refs for repository: " + repoName);
////	        System.out.println("Number of refs: " + refs.size());
////
////	        // If no refs are found, return an error or empty response
////	        if (refs.isEmpty()) {
////	            response.sendError(HttpServletResponse.SC_NOT_FOUND, "No references found in the repository: " + repoName);
////	            return;
////	        }
////
////	        // Set response headers for Git protocol
////	        response.setContentType("application/x-git-receive-pack-advertisement");
////	        response.setStatus(HttpServletResponse.SC_OK);
////
////	        // Write the service header for receive-pack (push)
////	        response.getWriter().write("# service=git-receive-pack\n");
////
////	        // Write refs in Git protocol format
////	        for (Ref ref : refs) {
////	            System.out.println("Ref: " + ref.getName());
////	            response.getWriter().write("002f" + ref.getName() + "\n");  // Send ref name for push
////	        }
//	        
//	        response.setStatus(200);
//	        
//
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving refs for push");
//	    }
//	}
//
	   @Override
	   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	       try {
	    	   System.out.println("Reached while");
	           // ✅ Ensure the correct Git service
	           String contentType = request.getContentType();
	           if (contentType == null || !contentType.contains("git-upload-pack-request")) {
	               response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid Git service request.");
	               return;
	           }
	    	   System.out.println("Step 2");
	           // ✅ Set response headers correctly for packfile transfer
	           response.setContentType("application/x-git-upload-pack-result");
	           response.setHeader("Expires", "Fri, 01 Jan 1980 00:00:00 GMT");
	           response.setHeader("Pragma", "no-cache");
	           response.setHeader("Cache-Control", "no-cache, max-age=0, must-revalidate");

	           // ✅ Run `git-upload-pack` correctly
	           File gitRepo = new File(REPO_PATH+"kabil.git"); // Your bare repo path
	           ProcessBuilder pb = new ProcessBuilder("git", "upload-pack", "--stateless-rpc", gitRepo.getAbsolutePath());
	           pb.redirectErrorStream(true);
	           Process gitProcess = pb.start();

	           // ✅ Debugging: Check if the process starts successfully
	    	   System.out.println("wait 3");
	           int exitCode = gitProcess.waitFor();
	    	   System.out.println("Step 3");
	           if (exitCode != 0) {
	               response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "git-upload-pack failed.");
	               return;
	           }
	           System.out.println("Step 4");

	           // ✅ Send client's request to `git-upload-pack`
	           try (OutputStream gitIn = gitProcess.getOutputStream();
	                InputStream clientRequest = request.getInputStream()) {
	        	   System.out.println("Step 5");
	               byte[] buffer = new byte[8192];
	               int bytesRead;
	               
	               while ((bytesRead = clientRequest.read(buffer)) != -1) {
	                   gitIn.write(buffer, 0, bytesRead);
	              
	               }
	               
                   System.out.println("hmm");
	               gitIn.flush();
	           }

	           // ✅ Read response from `git-upload-pack` and send it to the client
	           try (InputStream gitOut = gitProcess.getInputStream();
	                OutputStream clientResponse = response.getOutputStream()) {

	               byte[] buffer = new byte[8192];
	               int bytesRead;
	               while ((bytesRead = gitOut.read(buffer)) != -1) {
	                   clientResponse.write(buffer, 0, bytesRead);
	               }
	               System.out.println("ok");
	               clientResponse.flush();
	           }

	       } catch (Exception e) {
	           response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error handling Git upload-pack.");
	           e.printStackTrace();
	       }
	   }

	   
	   
	   
	   //old post method -1
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//
//        // Log the incoming POST request for Git push
//        System.out.println("POST request received for Git push");
//
//        String repoName = request.getPathInfo().substring(1);
//
//        File repoDir = new File(REPO_PATH + "repository-2" + ".git");
//
//        if (!repoDir.exists()) {
//            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Repository not found");
//            return;
//        }
//
//        // Invoke the git-http-backend process using ProcessBuilder to handle the push
//        try {
//            ProcessBuilder builder = new ProcessBuilder(
//                    "/usr/lib/git-core/git-http-backend", // Adjust path to git-http-backend as needed
//                    "--export-all",
//                    "--base-path=" + REPO_PATH,
//                    repoDir.getAbsolutePath());
//
//            builder.environment().put("GIT_PROJECT_ROOT", REPO_PATH);
//            builder.environment().put("GIT_HTTP_EXPORT_ALL", "true");
//
//            Process process = builder.start();
//            InputStream inputStream = process.getInputStream();
//            OutputStream outputStream = response.getOutputStream();
//
//            IOUtils.copy(inputStream, outputStream);
//
//            process.waitFor();
//            outputStream.close();
//            inputStream.close();
//
//        } catch (Exception e) {
//            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error pushing to Git repository");
//            e.printStackTrace();
//        }
//
//        // Handle the push using ReceivePack (using JGit API)
//        try {
//            Repository repository = Git.open(repoDir).getRepository();
//            ReceivePack receivePack = new ReceivePack(repository);
//
//            // Process the Git push request using ReceivePack
//            System.out.println("Processing push to repository: " + repoName);
//            receivePack.receive(request.getInputStream(), response.getOutputStream(), null);
//
//            // Send success response
//            response.setStatus(HttpServletResponse.SC_OK);
//            response.getWriter().write("Push successful to repository: " + repoName);
//        } catch (Exception e) {
//            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error handling Git push request");
//            e.printStackTrace();
//        }
//    }
}
