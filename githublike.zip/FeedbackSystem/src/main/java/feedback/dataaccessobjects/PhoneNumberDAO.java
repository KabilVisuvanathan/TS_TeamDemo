package feedback.dataaccessobjects;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import feedback.entities.Employee;
import feedback.entities.PhoneNumber;
import feedback.services.DBconnection;

public class PhoneNumberDAO {
	public ArrayList<PhoneNumber> getAllPhonenumbers() throws SQLException{
		
		Connection con =DBconnection.getConnection();
		
		String phonenumbersQuery = "select * from phonenumbers";
		PreparedStatement stmt = con.prepareStatement(phonenumbersQuery);
		
		ResultSet rs = stmt.executeQuery();
		ArrayList<PhoneNumber> phonenumbers = new ArrayList<PhoneNumber>();
		
		while(rs.next()) {
			int id = rs.getInt(1);
			String number = rs.getString(2);
			boolean isAvailable = rs.getBoolean(3);
			PhoneNumber ph = new PhoneNumber(number);
			ph.setAvailable(isAvailable);
			ph.setId(id);
			phonenumbers.add(ph);
		}
		
		return phonenumbers;
	
	}
	
	public PhoneNumber getPhonenumberById(int id) throws SQLException{
		
		Connection con =DBconnection.getConnection();
		
		String phonenumbersQuery = "select * from phonenumbers where id=?";
		PreparedStatement stmt = con.prepareStatement(phonenumbersQuery);
		stmt.setInt(1, id);
		ResultSet rs = stmt.executeQuery();
		
		
		if(rs.next()) {
			int ids = rs.getInt(1);
			String number = rs.getString(2);
			boolean isAvailable = rs.getBoolean(3);
			PhoneNumber ph = new PhoneNumber(number);
			ph.setAvailable(isAvailable);
			ph.setId(ids);
			return ph;
		}
		
		return null;
	
	}
	
}
