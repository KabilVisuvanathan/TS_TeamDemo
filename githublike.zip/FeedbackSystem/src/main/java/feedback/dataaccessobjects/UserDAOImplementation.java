package feedback.dataaccessobjects;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import feedback.entities.User;
import feedback.interfaces.UserDAO;
import feedback.services.DBconnection;
public class UserDAOImplementation implements UserDAO{

	@Override
	public User getUserByEmailaddress(String emailaddress) throws SQLException {
		
		Connection con =DBconnection.getConnection();
		
		String userRetrivalQuery = "select u.id,u.name,u.emailaddress,u.phonenumber,u.password,r.name from users u left join roles r on u.roleid=r.id where emailaddress=?";
		PreparedStatement stmt = con.prepareStatement(userRetrivalQuery);
		stmt.setString(1, emailaddress);
		
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			int userid = rs.getInt(1);
			String username = rs.getString(2);
			String emailAddress =  rs.getString(3);
			String phoneNumber = rs.getString(4);
			String password = rs.getString(5);
			String role =  rs.getString(6);
			User user =new User(username,emailAddress,phoneNumber,password,role);
			user.setId(userid);
			return user;
		}
		
		return null;
	}
	
public User getUserByPhonenumber(String number) throws SQLException {
		
		Connection con =DBconnection.getConnection();
		
		String userRetrivalQuery = "select u.id,u.name,u.emailaddress,u.phonenumber,u.password,r.name from users u left join roles r on u.roleid=r.id where phonenumber=?";
		PreparedStatement stmt = con.prepareStatement(userRetrivalQuery);
		stmt.setString(1, number);
		
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			int userid = rs.getInt(1);
			String username = rs.getString(2);
			String emailAddress =  rs.getString(3);
			String phoneNumber = rs.getString(4);
			String password = rs.getString(5);
			String role =  rs.getString(6);
			User user =new User(username,emailAddress,phoneNumber,password,role);
			user.setId(userid);
			return user;
		}
		
		return null;
	}
	
	
	public User getUserByid(int id) throws SQLException {
		
		Connection con =DBconnection.getConnection();
		
		String userRetrivalQuery = "select u.id,u.name,u.emailaddress,u.phonenumber,u.password,r.name from users u left join roles r on u.roleid=r.id where id=?";
		PreparedStatement stmt = con.prepareStatement(userRetrivalQuery);
		stmt.setInt(1, id);
		
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			int userid = rs.getInt(1);
			String username = rs.getString(2);
			String emailAddress =  rs.getString(3);
			String phoneNumber = rs.getString(4);
			String password = rs.getString(5);
			String role =  rs.getString(6);
			User user =new User(username,emailAddress,phoneNumber,password,role);
			user.setId(userid);
			return user;
		}
		
		return null;
	}

	@Override
	public ArrayList<User> getAllUsers() throws SQLException {
		Connection con =DBconnection.getConnection();
		String userRetrivalQuery = "select u.id,u.name,u.emailaddress,u.phonenumber,u.password,r.name from users u left join roles r on u.roleid=r.id";
		PreparedStatement stmt = con.prepareStatement(userRetrivalQuery);
		ResultSet rs = stmt.executeQuery();
		ArrayList<User> users = new ArrayList<User>();
		while(rs.next()) {
			int userid = rs.getInt(1);
			String username = rs.getString(2);
			String emailAddress =  rs.getString(3);
			String phoneNumber = rs.getString(4);
			String password = rs.getString(5);
			String role =  rs.getString(6);
			User user =new User(username,emailAddress,phoneNumber,password,role);
			user.setId(userid);
			users.add(user);
		}
		return users;
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addUser(User user) throws SQLException {
		Connection con =DBconnection.getConnection();
		String userRetrivalQuery = "insert into users(name,emailaddress,phonenumber,password,roleid) values(?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(userRetrivalQuery);
		int res = stmt.executeUpdate();
		if(res>0) {
			System.out.println("User added successfully.");
		}
	}

	@Override
	public void deleteUser(int id) throws SQLException {
		Connection con =DBconnection.getConnection();
		String userRetrivalQuery = "delete from users where id=?";
		PreparedStatement stmt = con.prepareStatement(userRetrivalQuery);
		stmt.setInt(1, id);
		int res = stmt.executeUpdate();
		if(res>0) {
			System.out.println("User deleted successfully.");
		}
	}

}
