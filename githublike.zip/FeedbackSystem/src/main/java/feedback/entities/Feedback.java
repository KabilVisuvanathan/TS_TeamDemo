package feedback.entities;

import java.time.LocalDateTime;

public class Feedback {
	private int id;
	private String content;
	private double ratings;
	private int tagid;
	private boolean flagged;
	
	private LocalDateTime createdAt,updatedAt;
	
	
	public Feedback(String content, double ratings, int tagid) {
		this.content = content;
		this.ratings = ratings;
		this.tagid = tagid;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public double getRatings() {
		return ratings;
	}


	public void setRatings(double ratings) {
		this.ratings = ratings;
	}


	public int getTagid() {
		return tagid;
	}


	public void setTagid(int tagid) {
		this.tagid = tagid;
	}


	public boolean isFlagged() {
		return flagged;
	}


	public void setFlagged(boolean flagged) {
		this.flagged = flagged;
	}

	public boolean getFlagged() {
		return this.flagged;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}


	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}


	public LocalDateTime getCreatedAt() {
		return createdAt;
	}


	

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	
	
	
}
