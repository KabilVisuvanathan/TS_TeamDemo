package feedback.dataaccessobjects;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import feedback.entities.CommonIssue;
import feedback.entities.Feedback;
import feedback.services.DBconnection;

public class CommonIssueDAO {
	
	public CommonIssue getCommonIssue(int id) throws SQLException {
		
		Connection con =DBconnection.getConnection();
			
			String commonIssueRetrive = "select * from common_issues where id = ?";
			
			PreparedStatement stmt = con.prepareStatement(commonIssueRetrive);
			stmt.setInt(1, id);
			
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
			
				int issueid = rs.getInt(1);
				String name = rs.getString(2);
				String priority = rs.getString(2);
				
				CommonIssue ci = new CommonIssue(name, priority);
				ci.setId(issueid);
				return ci;
				}
			
			return null;
	}
	
	
	public ArrayList<CommonIssue> getAllCommonIssues() throws SQLException {
		
		Connection con =DBconnection.getConnection();
			
			String commonIssueRetrive = "select * from common_issues";
			
			PreparedStatement stmt = con.prepareStatement(commonIssueRetrive);
		
			
			ResultSet rs = stmt.executeQuery();
			ArrayList<CommonIssue> cis = new ArrayList<CommonIssue>();
			while(rs.next()) {
			
				int issueid = rs.getInt(1);
				String name = rs.getString(2);
				String priority = rs.getString(2);
				
				CommonIssue ci = new CommonIssue(name, priority);
				ci.setId(issueid);
				cis.add(ci);
			
				}
			return cis;
	}
	
}
