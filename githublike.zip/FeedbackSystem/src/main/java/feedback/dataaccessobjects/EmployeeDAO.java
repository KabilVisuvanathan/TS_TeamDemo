package feedback.dataaccessobjects;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import feedback.entities.Employee;
import feedback.services.DBconnection;

public class EmployeeDAO {
	
	public ArrayList<Employee> getAllEmployees() throws SQLException{
		
		Connection con =DBconnection.getConnection();
		
		String allEmployees = "select * from employees";
		PreparedStatement stmt = con.prepareStatement(allEmployees);
		
		ResultSet rs = stmt.executeQuery();
		ArrayList<Employee> employees = new ArrayList<Employee>();
		
		while(rs.next()) {
			int empid = rs.getInt(1);
			String name  = rs.getString(2);
			Employee emp = new Employee(name);
			emp.setId(empid);
			employees.add(emp);
		}
		
		return employees;
	
	}
	
	public Employee getEmployeeById(int id) throws SQLException {
Connection con =DBconnection.getConnection();
		
		String allEmployees = "select * from employees where id =?";
		PreparedStatement stmt = con.prepareStatement(allEmployees);
		stmt.setInt(1, id);
		ResultSet rs = stmt.executeQuery();
	
		if(rs.next()) {
			int empid = rs.getInt(1);
			String name  = rs.getString(2);
			Employee emp = new Employee(name);
			emp.setId(empid);
			return emp;
		}
		
		return null;
	
	}
}
