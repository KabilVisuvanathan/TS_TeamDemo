package init;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;

public class GitHttpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
	private static final String REPO_BASE = "/home/raj-zstk371/Documents/Rajkumar/FeedbackSystem/src/main/webapp/all-repos";
    private static final String GIT_PATH = "/usr/bin/git"; // Path to Git executable
// /lib/git-core
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
        throws ServletException, IOException {
        
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || !pathInfo.endsWith("/info/refs")) {
            resp.sendError(400, "Invalid Git request");
            return;
        }

        // Extract repository path (e.g., "Rajkumar/test.git")
        String repoPath = pathInfo.replace("/info/refs", "").replaceFirst("^/", "");
        File repoDir = new File(REPO_BASE, repoPath);

        if (!repoDir.exists()) {
            resp.sendError(404, "Repository not found");
            return;
        }

        String service = req.getParameter("service");
        if (!"git-upload-pack".equals(service) && !"git-receive-pack".equals(service)) {
            resp.sendError(400, "Unsupported service: " + service);
            return;
        }

        try {
            String[] cmd = {
                GIT_PATH,
                service.replace("git-", ""), // "upload-pack" or "receive-pack"
                "--stateless-rpc",
                "--advertise-refs",
                repoDir.getAbsolutePath()
            };

            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            Process process = pb.start();

            // Write protocol header
            resp.setContentType("application/x-" + service + "-advertisement");
            resp.setHeader("Cache-Control", "no-cache");

            OutputStream out = resp.getOutputStream();
            out.write(("001e# service=" + service + "\n").getBytes());
            out.write("0000".getBytes()); // Flush packet

            // Pipe Git output to HTTP response
            try (InputStream gitOut = process.getInputStream()) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = gitOut.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
            }

            process.waitFor();
        } catch (Exception e) {
            resp.sendError(500, "Server error: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
        throws ServletException, IOException {
        
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || (!pathInfo.contains("/git-upload-pack") && !pathInfo.contains("/git-receive-pack"))) {
            resp.sendError(400, "Invalid Git request");
            return;
        }

        // Extract repository path
        String repoPath = pathInfo.replace("/git-upload-pack", "")
                                  .replace("/git-receive-pack", "")
                                  .replaceFirst("^/", "");
        File repoDir = new File(REPO_BASE, repoPath);

        if (!repoDir.exists()) {
            resp.sendError(404, "Repository not found");
            return;
        }

        String service = pathInfo.contains("upload-pack") ? "upload-pack" : "receive-pack";
        try {
            String[] cmd = {
                GIT_PATH,
                service,
                "--stateless-rpc",
                repoDir.getAbsolutePath()
            };

            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            Process process = pb.start();

            // Pipe HTTP request body to Git process
            try (OutputStream gitIn = process.getOutputStream();
                 InputStream httpIn = req.getInputStream()) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = httpIn.read(buffer)) != -1) {
                    gitIn.write(buffer, 0, bytesRead);
                }
            }

            // Pipe Git output to HTTP response
            resp.setContentType("application/x-git-" + service + "-result");
            try (InputStream gitOut = process.getInputStream();
                 OutputStream httpOut = resp.getOutputStream()) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = gitOut.read(buffer)) != -1) {
                    httpOut.write(buffer, 0, bytesRead);
                }
            }

            process.waitFor();
        } catch (Exception e) {
            resp.sendError(500, "Server error: " + e.getMessage());
        }
    }
}